#ifndef PREPROCESSING_H_
#define PREPROCESSING_H_
#define _GNU_SOURCE
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <stdlib.h>
#include <err.h>
#include <string.h>

unsigned int pre_processing(SDL_Surface *image_surface);

#endif
