#ifndef MODEL_H
#define MODEL_H

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <math.h>


void neuralNetwork(size_t size);

#endif
